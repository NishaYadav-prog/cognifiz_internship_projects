document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("userForm");
  const userList = document.getElementById("userList");

  // Load users on page load
  fetch("/api/users")
    .then((res) => res.json())
    .then((data) => displayUsers(data));

  // Add user
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();

    fetch("/api/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email }),
    })
      .then((res) => res.json())
      .then((data) => {
        alert("User added!");
        displayUsersFromAPI(); // Refresh user list
        form.reset();
      });
  });

  function displayUsers(users) {
    userList.innerHTML = "";
    users.forEach((user) => {
      const div = document.createElement("div");
      div.className = "user-card";
      div.innerHTML = `<strong>${user.name}</strong><br>${user.email}`;
      userList.appendChild(div);
    });
  }

  function displayUsersFromAPI() {
    fetch("/api/users")
      .then((res) => res.json())
      .then((data) => displayUsers(data));
  }
});
