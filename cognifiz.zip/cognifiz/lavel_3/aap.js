const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));
app.set("view engine", "ejs");

const dataPath = path.join(__dirname, "users.json");

// Read users
function getUsers() {
  const raw = fs.readFileSync(dataPath);
  return JSON.parse(raw);
}

// Routes
app.get("/", (req, res) => {
  res.render("index");
});

// API: GET users
app.get("/api/users", (req, res) => {
  res.json(getUsers());
});

// API: POST new user
app.post("/api/users", (req, res) => {
  const users = getUsers();
  const newUser = {
    id: Date.now(),
    name: req.body.name,
    email: req.body.email,
  };
  users.push(newUser);
  fs.writeFileSync(dataPath, JSON.stringify(users, null, 2));
  res.status(201).json({ message: "User added", user: newUser });
});

app.listen(PORT, () =>
  console.log(`Server running on http://localhost:${PORT}`)
);
